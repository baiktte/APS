import sys
sys.stdin = open("1258.txt", "r")

T = int(input())

for t in range(1,T+1):
    N = int(input())
    lst = []
    for i in range(N):
        lsts = list(map(int, input().split()))
        lst.append(lsts)
    cnt = 0
    count = []
    for i in range(N):
        cnt=0
        for j in range(N):
            if lst[i][j] !=0:
                cnt+=1
        count.append(cnt)
    
    # count의 최댓값+1 길이의 a 리스트를 만듬(0으로 초기화)
    result =[0]*(max(count)+1)
    # 배열속 수를 result[수]에 축적
    for e in count:
        result[e]+=1
    my=[]
    for i in range(1,len(result)):
        if result[i]!=0:
            my.append(i)
            my.append(result[i])
    my.insert(0, len(my)//2)

    end = '#{} '.format(t)
    for i in range(len(my)):
        end += str(my[i])
        # 공백 마지막에 안넣기 위해
        if i != len(my) - 1:
            end += ' '

    print(end)

